function abrirModal() {
    document.getElementById('promocao').style.marginTop = '-1600px';
    document.getElementById('cortina').style.backgroundColor = 'rgba(0,0,0,0.7)';
    document.getElementById('cortina').style.zIndex = '200';
}
function fecharModal() {
    document.getElementById('promocao').style.marginTop = '-5500px';
    document.getElementById('cortina').style.backgroundColor = 'rgba(0,0,0,0)';
    document.getElementById('cortina').style.zIndex = '1';
}
function validarFormulario() {
    var nome = document.getElementById('fid-nome').value;
    var email = document.getElementById('fid-email').value;

    if (nome == '' && email == '') {
        document.getElementById('fid-nome').style.border = 'solid 0.2px red';
        document.getElementById('fid-email').style.border = 'solid 0.2px red';
        document.getElementById('msg-erro').innerHTML = 'Informe todos os campos obrigatórios (*)!'
        document.getElementById('msg-erro').style.color = 'red';
    } else if (nome == '' && email != '') {
        document.getElementById('fid-nome').style.border = 'solid 0.2px red';
        document.getElementById('fid-email').style.border = 'none';
        document.getElementById('msg-erro').innerHTML = 'Informe o campo nome!'
    } else if (nome != '' && email == '') {
        document.getElementById('fid-nome').style.border = 'none';
        document.getElementById('fid-email').style.border = 'solid 0.2px red';
        document.getElementById('msg-erro').innerHTML = 'Informe o campo e-mail!'
    } else {
        document.getElementById('fid-nome').style.border = 'none';
        document.getElementById('fid-email').style.border = 'none';
        document.getElementById('msg-erro').innerHTML = 'Dados enviados com sucesso!'
        document.getElementById('msg-erro').style.color = 'green';
    }

}

function limpar() {
    document.getElementById('fid-nome').style.border = 'none';
    document.getElementById('fid-email').style.border = 'none';
    document.getElementById('msg-erro').innerHTML = ''
}

